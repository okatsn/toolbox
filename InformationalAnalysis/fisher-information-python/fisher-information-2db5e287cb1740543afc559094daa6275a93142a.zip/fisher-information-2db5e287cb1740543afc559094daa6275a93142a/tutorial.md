A tutorial is available at http://csun.uic.edu/codes/fisher.html
