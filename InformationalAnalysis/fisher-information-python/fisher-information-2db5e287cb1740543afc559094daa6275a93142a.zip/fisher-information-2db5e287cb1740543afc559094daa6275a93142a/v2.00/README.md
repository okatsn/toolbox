README - Fisher Information

Derrible, S., Eason, T., Cabezas, H., (2016) Using Fisher information to track stability in multivariate systems, Royal Society Open Science, 3:160582; DOI: 10.1098/rsos.160582.

More information and a tutorial is available at: http://csun.uic.edu/data.html#fisher

version 2.00 - for Python 3


What’s new

- Code modified to work with Python 3
